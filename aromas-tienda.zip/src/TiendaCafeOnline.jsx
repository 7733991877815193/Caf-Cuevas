import React from "react";

export default function TiendaCafeOnline() {
  const productos = [
    {
      nombre: "Café de Cuevas - 250g",
      descripcion: "Café de especialidad, notas florales y frutales, acidez media-alta.",
      precio: "$12 USD",
      imagen: "https://source.unsplash.com/featured/?coffee"
    },
    {
      nombre: "Café de Cuevas - 500g",
      descripcion: "Ideal para consumidores frecuentes. Origen: Samaipata, Bolivia.",
      precio: "$20 USD",
      imagen: "https://source.unsplash.com/featured/?coffee-bag"
    },
    {
      nombre: "Kit Gourmet de Regalo",
      descripcion: "Incluye café 250g, taza artesanal, guía de cata.",
      precio: "$25 USD",
      imagen: "https://source.unsplash.com/featured/?gift-coffee"
    },
    {
      nombre: "Suscripción Mensual",
      descripcion: "Recibe cada mes 500g de café con envío incluido y beneficios exclusivos.",
      precio: "$18 USD/mes",
      imagen: "https://source.unsplash.com/featured/?subscription-coffee"
    }
  ];

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-3xl font-bold text-center">Tienda Online - Aromas de los Andes</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {productos.map((producto, index) => (
          <div key={index} className="rounded-2xl shadow-lg bg-white">
            <img src={producto.imagen} alt={producto.nombre} className="w-full h-48 object-cover rounded-t-2xl" />
            <div className="space-y-3 p-4">
              <h2 className="text-xl font-semibold">{producto.nombre}</h2>
              <p className="text-sm text-gray-600">{producto.descripcion}</p>
              <p className="text-lg font-bold text-green-700">{producto.precio}</p>
              <button className="w-full bg-green-700 text-white py-2 rounded-xl hover:bg-green-800">Comprar</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
